import Link from 'next/link';
export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="max-w-md w-full bg-white p-6 rounded shadow">
        <h1 className="text-xl font-bold mb-4">Task & Referral Platform</h1>
        <div className="space-x-2">
          <Link href="/auth/register"><a className="px-4 py-2 bg-blue-600 text-white rounded">Register</a></Link>
          <Link href="/auth/login"><a className="px-4 py-2 bg-gray-200 rounded">Login</a></Link>
          <Link href="/admin/login"><a className="px-4 py-2 bg-green-600 text-white rounded float-right">Admin</a></Link>
        </div>
      </div>
    </div>
  );
}
