import { useEffect, useState } from 'react';
import axios from 'axios';
export default function AdminDashboard() {
  const [submissions, setSubmissions] = useState([]);
  const API = process.env.NEXT_PUBLIC_API_URL;
  useEffect(()=>{(async ()=>{
    const token = localStorage.getItem('admin_token');
    if(!token) return;
    const r = await axios.get(`${API}/api/admin/task_submissions`, { headers: { Authorization: 'Bearer '+token } });
    setSubmissions(r.data);
  })()},[]);

  async function approve(id) {
    const token = localStorage.getItem('admin_token');
    await axios.post(`${API}/api/admin/task_submissions/${id}/approve`, {}, { headers: { Authorization: 'Bearer '+token } });
    alert('Approved');
  }

  return (
    <div className="max-w-4xl mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Admin Dashboard</h1>
      <div className="space-y-4">
        {submissions.map(s=>(
          <div key={s.id} className="p-4 bg-white rounded shadow">
            <div><strong>{s.title}</strong> by {s.user_name}</div>
            <div>Reward: ₦{s.reward_amount}</div>
            <div className="mt-2"><button className="px-3 py-1 bg-green-600 text-white rounded" onClick={()=>approve(s.id)}>Approve</button></div>
          </div>
        ))}
      </div>
    </div>
  );
}
