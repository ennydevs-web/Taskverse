import { useEffect, useState } from 'react';
import axios from 'axios';
export default function Tasks() {
  const [tasks, setTasks] = useState([]);
  const API = process.env.NEXT_PUBLIC_API_URL;
  useEffect(()=>{(async ()=>{
    const token = localStorage.getItem('token');
    if(!token) return;
    const r = await axios.get(`${API}/api/tasks`, { headers: { Authorization: 'Bearer '+token } });
    setTasks(r.data);
  })()},[]);

  return (
    <div className="max-w-3xl mx-auto p-4">
      <h2 className="text-xl font-bold mb-4">Tasks</h2>
      <div className="space-y-4">
        {tasks.map(t=>(
          <div key={t.id} className="p-4 bg-white rounded shadow">
            <div className="font-bold">{t.title}</div>
            <div className="text-sm">Reward: ₦{t.reward_amount}</div>
            <div className="mt-2"><a className="text-blue-600" href={`/dashboard/tasks/${t.id}`}>Submit Proof</a></div>
          </div>
        ))}
      </div>
    </div>
  );
}
