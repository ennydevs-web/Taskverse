import { useEffect, useState } from 'react';
import axios from 'axios';
export default function Referrals() {
  const [data, setData] = useState(null);
  const API = process.env.NEXT_PUBLIC_API_URL;
  useEffect(()=>{(async ()=>{
    const token = localStorage.getItem('token');
    if(!token) return;
    const r = await axios.get(`${API}/api/referrals`, { headers: { Authorization: 'Bearer '+token } });
    setData(r.data);
  })()},[]);

  if(!data) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;

  return (
    <div className="max-w-3xl mx-auto p-4">
      <h2 className="text-xl font-bold mb-4">Referrals</h2>
      <div className="p-4 bg-white rounded shadow">
        <div>Referral Link:</div>
        <div className="text-blue-600 break-all">{data.referral_link}</div>
        <div className="mt-2">Referrals: {data.referrals_count}</div>
        <div>Referral Earnings: ₦{data.referral_earnings}</div>
      </div>
    </div>
  );
}
