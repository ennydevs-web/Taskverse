import { useState } from 'react';
import axios from 'axios';
export default function Withdrawals() {
  const [amount, setAmount] = useState('');
  const API = process.env.NEXT_PUBLIC_API_URL;

  async function request() {
    const token = localStorage.getItem('token');
    if(!token) return alert('Login required');
    try {
      const r = await axios.post(`${API}/api/withdrawals`, { amount }, { headers: { Authorization: 'Bearer '+token } });
      alert('Withdrawal requested');
    } catch (err) {
      alert(err.response?.data?.error || 'Failed');
    }
  }

  return (
    <div className="max-w-3xl mx-auto p-4">
      <h2 className="text-xl font-bold mb-4">Withdraw</h2>
      <div className="p-4 bg-white rounded shadow">
        <input className="w-full p-2 border mb-2" placeholder="Amount" value={amount} onChange={e=>setAmount(e.target.value)} />
        <button className="w-full py-2 bg-blue-600 text-white rounded" onClick={request}>Request Withdrawal</button>
      </div>
    </div>
  );
}
