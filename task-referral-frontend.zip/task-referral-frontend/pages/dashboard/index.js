import { useEffect, useState } from 'react';
import axios from 'axios';
export default function Dashboard() {
  const [me, setMe] = useState(null);
  const API = process.env.NEXT_PUBLIC_API_URL;
  useEffect(()=>{(async ()=>{
    const token = localStorage.getItem('token');
    if(!token) return;
    try {
      const r = await axios.get(`${API}/api/me`, { headers: { Authorization: 'Bearer '+token } });
      setMe(r.data);
    } catch (err) { console.error(err); }
  })()},[]);

  if(!me) return <div className="min-h-screen flex items-center justify-center">Please login</div>;

  return (
    <div className="max-w-3xl mx-auto p-4">
      <h1 className="text-2xl font-bold">Welcome, {me.name}</h1>
      <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 bg-white rounded shadow">
          <div className="text-sm">Wallet Balance</div>
          <div className="text-xl font-bold">₦{me.wallet_balance}</div>
        </div>
        <div className="p-4 bg-white rounded shadow">
          <div className="text-sm">Referrals</div>
          <div className="text-xl font-bold"><a href="/dashboard/referrals">View</a></div>
        </div>
        <div className="p-4 bg-white rounded shadow">
          <div className="text-sm">Tasks</div>
          <div className="text-xl font-bold"><a href="/dashboard/tasks">Open</a></div>
        </div>
      </div>
    </div>
  );
}
