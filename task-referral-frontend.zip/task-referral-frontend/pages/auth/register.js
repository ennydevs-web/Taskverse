import { useState } from 'react';
import axios from 'axios';
import { useRouter } from 'next/router';
export default function Register() {
  const [form, setForm] = useState({ name: '', email: '', phone: '', password: '', ref: '' });
  const router = useRouter();
  const API = process.env.NEXT_PUBLIC_API_URL;

  async function onSubmit(e) {
    e.preventDefault();
    try {
      const res = await axios.post(`${API}/api/auth/register`, { name: form.name, email: form.email, phone: form.phone, password: form.password, referral_code: form.ref });
      alert('Registered. Proceed to payment initialize (see console).');
      console.log(res.data);
      // initialize activation (optional):
      const init = await axios.post(`${API}/api/payments/initialize-activation`, { userId: res.data.user.id, callback_url: window.location.origin + '/payments/complete' });
      console.log('Paystack init:', init.data);
      if (init.data && init.data.data && init.data.data.authorization_url) {
        window.location.href = init.data.data.authorization_url;
      }
    } catch (err) {
      alert(err.response?.data?.error || 'Registration failed');
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center">
      <form onSubmit={onSubmit} className="bg-white p-6 rounded shadow w-full max-w-md">
        <h2 className="text-lg font-bold mb-4">Register</h2>
        <input className="w-full p-2 border mb-2" placeholder="Name" value={form.name} onChange={e=>setForm({...form, name: e.target.value})} />
        <input className="w-full p-2 border mb-2" placeholder="Email" value={form.email} onChange={e=>setForm({...form, email: e.target.value})} />
        <input className="w-full p-2 border mb-2" placeholder="Phone" value={form.phone} onChange={e=>setForm({...form, phone: e.target.value})} />
        <input type="password" className="w-full p-2 border mb-2" placeholder="Password" value={form.password} onChange={e=>setForm({...form, password: e.target.value})} />
        <input className="w-full p-2 border mb-2" placeholder="Referral code (optional)" value={form.ref} onChange={e=>setForm({...form, ref: e.target.value})} />
        <button className="w-full py-2 bg-blue-600 text-white rounded">Register & Pay ₦500</button>
      </form>
    </div>
  );
}
