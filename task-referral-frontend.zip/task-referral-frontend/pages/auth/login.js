import { useState } from 'react';
import axios from 'axios';
import { useRouter } from 'next/router';
export default function Login() {
  const [form, setForm] = useState({ email: '', password: '' });
  const router = useRouter();
  const API = process.env.NEXT_PUBLIC_API_URL;

  async function onSubmit(e) {
    e.preventDefault();
    try {
      const res = await axios.post(`${API}/api/auth/login`, form);
      localStorage.setItem('token', res.data.token);
      alert('Logged in');
      router.push('/dashboard');
    } catch (err) {
      alert(err.response?.data?.error || 'Login failed');
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center">
      <form onSubmit={onSubmit} className="bg-white p-6 rounded shadow w-full max-w-md">
        <h2 className="text-lg font-bold mb-4">Login</h2>
        <input className="w-full p-2 border mb-2" placeholder="Email" value={form.email} onChange={e=>setForm({...form, email: e.target.value})} />
        <input type="password" className="w-full p-2 border mb-2" placeholder="Password" value={form.password} onChange={e=>setForm({...form, password: e.target.value})} />
        <button className="w-full py-2 bg-blue-600 text-white rounded">Login</button>
      </form>
    </div>
  );
}
