Next.js frontend with Tailwind

Run:
1. npm install
2. copy .env.local.example to .env.local and set NEXT_PUBLIC_API_URL
3. npm run dev
