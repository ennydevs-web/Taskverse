require('dotenv').config();

module.exports = {
  PORT: process.env.PORT || 4000,
  DATABASE_URL: process.env.DATABASE_URL || process.env.DB_URL,
  JWT_SECRET: process.env.JWT_SECRET || 'change_me',
  PAYSTACK_SECRET: process.env.PAYSTACK_SECRET || '',
  PAYSTACK_PUBLIC: process.env.PAYSTACK_PUBLIC || '',
  REFERRAL_BONUS: Number(process.env.REFERRAL_BONUS || 200),
  ACTIVATION_FEE: Number(process.env.ACTIVATION_FEE || 500),
  WITHDRAWAL_FEE: Number(process.env.WITHDRAWAL_FEE || 100),
  WITHDRAWAL_THRESHOLD: Number(process.env.WITHDRAWAL_THRESHOLD || 2000)
};
