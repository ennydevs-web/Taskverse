function generateReferralCode(userId) {
  return `R${userId.toString(36).toUpperCase()}${Math.random().toString(36).substring(2,6).toUpperCase()}`;
}

module.exports = { generateReferralCode };
