require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');

const authRoutes = require('./routes/auth');
const paymentsRoutes = require('./routes/payments');
const tasksRoutes = require('./routes/tasks');
const referralsRoutes = require('./routes/referrals');
const withdrawalsRoutes = require('./routes/withdrawals');
const adminRoutes = require('./routes/admin');
const adminAuthRoutes = require('./routes/adminAuth');

const { PORT = 4000 } = process.env;
const app = express();

app.use(cors());
app.use(bodyParser.json({ limit: '10mb' }));
app.use(bodyParser.urlencoded({ extended: true }));

app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use('/api/auth', authRoutes);
app.use('/api/payments', paymentsRoutes);
app.use('/api/tasks', tasksRoutes);
app.use('/api/referrals', referralsRoutes);
app.use('/api/withdrawals', withdrawalsRoutes);
app.use('/api/admin/auth', adminAuthRoutes);
app.use('/api/admin', adminRoutes);

app.get('/', (req, res) => res.send('Task Referral API running'));

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
