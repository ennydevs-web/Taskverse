Backend with Admin JWT Auth

Run:
1. npm install
2. copy .env.example to .env
3. npm run migrate
4. npm run seed-admin
5. npm run dev

Admin login at POST /api/admin/auth/login with { email, password }
Use returned JWT with Authorization: Bearer <token> for admin routes.
