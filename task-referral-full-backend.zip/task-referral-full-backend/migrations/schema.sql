-- users
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  phone VARCHAR(30),
  password_hash TEXT NOT NULL,
  referral_code VARCHAR(50) UNIQUE NOT NULL,
  referred_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  wallet_balance NUMERIC(12,2) DEFAULT 0,
  bank_name VARCHAR(255),
  bank_account_number VARCHAR(50),
  bank_code VARCHAR(20),
  is_active BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now()
);

-- transactions
CREATE TABLE IF NOT EXISTS transactions (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  type VARCHAR(30) NOT NULL,
  amount NUMERIC(12,2) NOT NULL,
  status VARCHAR(20) DEFAULT 'pending',
  meta JSONB,
  created_at TIMESTAMP DEFAULT now()
);

-- tasks
CREATE TABLE IF NOT EXISTS tasks (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  reward_amount NUMERIC(10,2) NOT NULL,
  proof_type VARCHAR(20) NOT NULL,
  created_at TIMESTAMP DEFAULT now(),
  is_active BOOLEAN DEFAULT TRUE
);

-- task_submissions
CREATE TABLE IF NOT EXISTS task_submissions (
  id SERIAL PRIMARY KEY,
  task_id INTEGER REFERENCES tasks(id) ON DELETE CASCADE,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  proof_url TEXT,
  status VARCHAR(20) DEFAULT 'pending',
  admin_note TEXT,
  created_at TIMESTAMP DEFAULT now()
);

-- withdrawals
CREATE TABLE IF NOT EXISTS withdrawals (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
  amount NUMERIC(12,2) NOT NULL,
  fee NUMERIC(10,2) NOT NULL DEFAULT 100.00,
  status VARCHAR(20) DEFAULT 'pending',
  paystack_transfer_ref TEXT,
  created_at TIMESTAMP DEFAULT now()
);

-- admin_users
CREATE TABLE IF NOT EXISTS admin_users (
  id SERIAL PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  name VARCHAR(255),
  created_at TIMESTAMP DEFAULT now()
);
