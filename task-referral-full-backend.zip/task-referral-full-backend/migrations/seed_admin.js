/**
 * Seed admin user using ADMIN_SEED_EMAIL and ADMIN_SEED_PASSWORD env vars.
 * Run: npm run seed-admin
 */
const { Pool } = require('pg');
const bcrypt = require('bcrypt');
require('dotenv').config();
const pool = new Pool({ connectionString: process.env.DATABASE_URL || process.env.DB_URL });

async function run() {
  const email = process.env.ADMIN_SEED_EMAIL;
  const password = process.env.ADMIN_SEED_PASSWORD;
  if (!email || !password) {
    console.error('Set ADMIN_SEED_EMAIL and ADMIN_SEED_PASSWORD in .env');
    process.exit(1);
  }
  const hashed = await bcrypt.hash(password, 10);
  const r = await pool.query('SELECT id FROM admin_users WHERE email = $1', [email]);
  if (r.rows.length) {
    console.log('Admin already exists');
    process.exit(0);
  }
  await pool.query('INSERT INTO admin_users (email, password_hash, name) VALUES ($1,$2,$3)', [email, hashed, 'Admin']);
  console.log('Admin seeded');
  process.exit(0);
}

run().catch(err => { console.error(err); process.exit(1); });
