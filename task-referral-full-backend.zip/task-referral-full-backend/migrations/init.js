const { Pool } = require('pg');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const pool = new Pool({ connectionString: process.env.DATABASE_URL || process.env.DB_URL });

async function run() {
  const schema = fs.readFileSync(path.join(__dirname, 'schema.sql')).toString();
  await pool.query(schema);
  console.log('Migrations applied');
  process.exit(0);
}

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
