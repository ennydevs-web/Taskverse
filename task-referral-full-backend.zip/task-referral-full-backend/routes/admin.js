const express = require('express');
const db = require('../db');
const { adminGuard } = require('../middleware/auth');
const { createTransferRecipient, initiateTransfer, resolveBankAccount } = require('../services/paystack');

const router = express.Router();

router.get('/users', adminGuard, async (req, res) => {
  const q = req.query.q || '';
  const r = await db.query(`SELECT id, name, email, phone, wallet_balance, referred_by, is_active, created_at FROM users WHERE email ILIKE $1 OR name ILIKE $1 ORDER BY created_at DESC`, [`%${q}%`]);
  res.json(r.rows);
});

router.post('/tasks', adminGuard, async (req, res) => {
  const { title, description, reward_amount, proof_type } = req.body;
  if (!title || !reward_amount || !proof_type) return res.status(400).json({ error: 'Missing fields' });
  const r = await db.query('INSERT INTO tasks (title, description, reward_amount, proof_type, is_active) VALUES ($1,$2,$3,$4,$5) RETURNING *', [title, description, reward_amount, proof_type, true]);
  res.json(r.rows[0]);
});

router.get('/task_submissions', adminGuard, async (req, res) => {
  const r = await db.query('SELECT ts.*, t.title, t.reward_amount, u.name as user_name FROM task_submissions ts JOIN tasks t ON ts.task_id = t.id JOIN users u ON ts.user_id = u.id ORDER BY ts.created_at DESC');
  res.json(r.rows);
});

router.post('/task_submissions/:id/approve', adminGuard, async (req, res) => {
  const id = req.params.id;
  const s = await db.query('SELECT ts.*, t.reward_amount FROM task_submissions ts JOIN tasks t ON ts.task_id = t.id WHERE ts.id = $1', [id]);
  if (!s.rows.length) return res.status(404).json({ error: 'Submission not found' });
  const sub = s.rows[0];

  try {
    await db.pool.query('BEGIN');
    await db.query('UPDATE task_submissions SET status = $1 WHERE id = $2', ['approved', id]);
    await db.query('UPDATE users SET wallet_balance = wallet_balance + $1 WHERE id = $2', [sub.reward_amount, sub.user_id]);
    await db.query('INSERT INTO transactions (user_id, type, amount, status, meta) VALUES ($1,$2,$3,$4,$5)', [sub.user_id, 'task', sub.reward_amount, 'approved', JSON.stringify({ submission_id: id })]);
    await db.pool.query('COMMIT');
    return res.json({ ok: true });
  } catch (err) {
    await db.pool.query('ROLLBACK');
    console.error('approve submission error', err);
    return res.status(500).json({ error: 'Failed to approve submission' });
  }
});

router.post('/task_submissions/:id/reject', adminGuard, async (req, res) => {
  const id = req.params.id;
  const { note } = req.body;
  await db.query('UPDATE task_submissions SET status = $1, admin_note = $2 WHERE id = $3', ['rejected', note || null, id]);
  return res.json({ ok: true });
});

router.get('/withdrawals', adminGuard, async (req, res) => {
  const r = await db.query('SELECT w.*, u.name, u.email, u.bank_name, u.bank_account_number, u.bank_code FROM withdrawals w JOIN users u ON w.user_id = u.id ORDER BY w.created_at DESC');
  res.json(r.rows);
});

router.post('/withdrawals/:id/approve', adminGuard, async (req, res) => {
  const id = req.params.id;
  const wres = await db.query('SELECT w.*, u.name, u.bank_account_number, u.bank_name, u.bank_code FROM withdrawals w JOIN users u ON w.user_id = u.id WHERE w.id = $1', [id]);
  if (!wres.rows.length) return res.status(404).json({ error: 'Withdrawal not found' });
  const withdrawal = wres.rows[0];

  try {
    const resolve = await resolveBankAccount(withdrawal.bank_account_number, withdrawal.bank_code);
    if (!resolve || !resolve.status) {
      console.warn('bank resolve failed', resolve);
      return res.status(400).json({ error: 'Failed to resolve bank account' });
    }

    const account_name = resolve.data.account_name;

    const recipientRes = await createTransferRecipient({ name: account_name, account_number: withdrawal.bank_account_number, bank_code: withdrawal.bank_code });
    if (!recipientRes || !recipientRes.status) {
      console.warn('create recipient failed', recipientRes);
      return res.status(400).json({ error: 'Failed to create transfer recipient' });
    }
    const recipient_code = recipientRes.data.recipient_code;

    const amountKobo = Math.round(Number(withdrawal.amount) * 100);
    const transferRes = await initiateTransfer({ amountKobo, recipient: recipient_code });
    if (!transferRes || !transferRes.status) {
      console.warn('transfer failed', transferRes);
      return res.status(400).json({ error: 'Transfer initiation failed' });
    }

    await db.pool.query('BEGIN');
    await db.query('UPDATE withdrawals SET status = $1, paystack_transfer_ref = $2 WHERE id = $3', ['paid', transferRes.data.reference, id]);
    await db.query('INSERT INTO transactions (user_id, type, amount, status, meta) VALUES ($1,$2,$3,$4,$5)', [withdrawal.user_id, 'withdrawal', withdrawal.amount, 'paid', JSON.stringify({ transfer_ref: transferRes.data.reference })]);
    await db.pool.query('COMMIT');

    return res.json({ ok: true, transfer: transferRes.data });
  } catch (err) {
    await db.pool.query('ROLLBACK');
    console.error('approve withdrawal error', err);
    return res.status(500).json({ error: 'Failed to approve withdrawal' });
  }
});

router.post('/withdrawals/:id/reject', adminGuard, async (req, res) => {
  const id = req.params.id;
  const r = await db.query('SELECT * FROM withdrawals WHERE id = $1', [id]);
  if (!r.rows.length) return res.status(404).json({ error: 'Withdrawal not found' });
  const w = r.rows[0];

  try {
    await db.pool.query('BEGIN');
    await db.query('UPDATE users SET wallet_balance = wallet_balance + $1 WHERE id = $2', [Number(w.amount) + Number(w.fee), w.user_id]);
    await db.query('UPDATE withdrawals SET status = $1 WHERE id = $2', ['rejected', id]);
    await db.query('INSERT INTO transactions (user_id, type, amount, status, meta) VALUES ($1,$2,$3,$4,$5)', [w.user_id, 'withdrawal_refund', w.amount, 'approved', JSON.stringify({ withdrawal_id: id })]);
    await db.pool.query('COMMIT');
    return res.json({ ok: true });
  } catch (err) {
    await db.pool.query('ROLLBACK');
    console.error('reject withdrawal error', err);
    return res.status(500).json({ error: 'Failed to reject withdrawal' });
  }
});

module.exports = router;
