const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const db = require('../db');
const { JWT_SECRET } = require('../config');

const router = express.Router();

// Admin login - checks admin_users table and returns JWT with isAdmin flag
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const r = await db.query('SELECT id, email, password_hash, name FROM admin_users WHERE email = $1', [email]);
  if (!r.rows.length) return res.status(400).json({ error: 'Invalid credentials' });
  const admin = r.rows[0];
  const ok = await bcrypt.compare(password, admin.password_hash);
  if (!ok) return res.status(400).json({ error: 'Invalid credentials' });
  const token = jwt.sign({ id: admin.id, email: admin.email, isAdmin: true }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, admin: { id: admin.id, email: admin.email, name: admin.name } });
});

module.exports = router;
