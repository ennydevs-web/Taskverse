const express = require('express');
const multer = require('multer');
const path = require('path');
const { auth } = require('../middleware/auth');
const db = require('../db');

const router = express.Router();

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, path.join(__dirname, '..', 'uploads'));
  },
  filename: function (req, file, cb) {
    const ext = path.extname(file.originalname);
    const id = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, `${id}${ext}`);
  }
});
const upload = multer({ storage, limits: { fileSize: 5 * 1024 * 1024 } });

router.get('/', auth, async (req, res) => {
  const r = await db.query('SELECT id, title, description, reward_amount, proof_type, created_at FROM tasks WHERE is_active = true ORDER BY created_at DESC');
  res.json(r.rows);
});

router.post('/:id/submit', auth, upload.single('proof'), async (req, res) => {
  const taskId = req.params.id;
  const userId = req.user.id;
  const t = await db.query('SELECT * FROM tasks WHERE id = $1 AND is_active = true', [taskId]);
  if (!t.rows.length) return res.status(404).json({ error: 'Task not found' });

  const proofUrl = req.file ? `/uploads/${req.file.filename}` : req.body.proof_url;
  if (!proofUrl) return res.status(400).json({ error: 'Missing proof' });

  await db.query('INSERT INTO task_submissions (task_id, user_id, proof_url, status) VALUES ($1,$2,$3,$4)', [taskId, userId, proofUrl, 'pending']);
  res.json({ ok: true, message: 'Submission created, awaiting admin review' });
});

router.get('/submissions', auth, async (req, res) => {
  const r = await db.query('SELECT ts.*, t.title, t.reward_amount FROM task_submissions ts JOIN tasks t ON ts.task_id = t.id WHERE ts.user_id = $1 ORDER BY ts.created_at DESC', [req.user.id]);
  res.json(r.rows);
});

module.exports = router;
