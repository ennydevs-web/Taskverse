const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const db = require('../db');
const { generateReferralCode } = require('../utils/referral');
const { JWT_SECRET } = require('../config');

const router = express.Router();

router.post('/register', async (req, res) => {
  const { name, email, phone, password, referral_code } = req.body;
  if (!name || !email || !password) return res.status(400).json({ error: 'Missing required fields' });

  const hashed = await bcrypt.hash(password, 10);
  try {
    const result = await db.query(
      `INSERT INTO users (name, email, phone, password_hash, referral_code) VALUES ($1,$2,$3,$4,$5) RETURNING *`,
      [name, email, phone, hashed, 'TEMP']
    );
    const user = result.rows[0];
    const code = generateReferralCode(user.id);
    await db.query('UPDATE users SET referral_code = $1 WHERE id = $2', [code, user.id]);

    if (referral_code) {
      const r = await db.query('SELECT id FROM users WHERE referral_code = $1', [referral_code]);
      if (r.rows.length) {
        await db.query('UPDATE users SET referred_by = $1 WHERE id = $2', [r.rows[0].id, user.id]);
      }
    }

    return res.json({ ok: true, user: { id: user.id, email: user.email, referral_code: code } });
  } catch (err) {
    console.error('register error', err);
    if (err.code === '23505') return res.status(400).json({ error: 'Email already registered' });
    return res.status(500).json({ error: 'Registration failed' });
  }
});

router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const r = await db.query('SELECT id, email, password_hash, name, is_active FROM users WHERE email = $1', [email]);
  if (!r.rows.length) return res.status(400).json({ error: 'Invalid credentials' });
  const user = r.rows[0];
  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) return res.status(400).json({ error: 'Invalid credentials' });

  const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, email: user.email, name: user.name, is_active: user.is_active } });
});

module.exports = router;
