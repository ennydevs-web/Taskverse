const express = require('express');
const crypto = require('crypto');
const db = require('../db');
const { initializeTransaction, verifyTransaction } = require('../services/paystack');
const { ACTIVATION_FEE, REFERRAL_BONUS } = require('../config');

const router = express.Router();

router.post('/initialize-activation', async (req, res) => {
  const { userId, callback_url } = req.body;
  if (!userId) return res.status(400).json({ error: 'Missing userId' });

  const r = await db.query('SELECT email FROM users WHERE id = $1', [userId]);
  if (!r.rows.length) return res.status(404).json({ error: 'User not found' });
  const email = r.rows[0].email;
  const amountKobo = ACTIVATION_FEE * 100;

  try {
    const init = await initializeTransaction(email, amountKobo, callback_url, { userId });
    return res.json(init);
  } catch (err) {
    console.error('init payment error', err);
    return res.status(500).json({ error: 'Failed to initialize payment' });
  }
});

router.post('/webhook', express.json({ type: '*/*' }), async (req, res) => {
  const signature = req.headers['x-paystack-signature'];
  const secret = process.env.PAYSTACK_SECRET || '';
  if (secret && signature) {
    const hash = crypto.createHmac('sha512', secret).update(JSON.stringify(req.body)).digest('hex');
    if (hash !== signature) {
      return res.status(400).send('invalid signature');
    }
  }

  const event = req.body;
  try {
    if (event.event === 'charge.success') {
      const reference = event.data.reference;
      const verify = await verifyTransaction(reference);
      if (!verify.status) {
        console.warn('verify failed', verify);
        return res.status(200).send('ok');
      }
      const { data } = verify;
      const metadata = data.metadata || {};
      const userId = metadata.userId || null;
      const email = data.customer?.email;

      let user;
      if (userId) {
        const r = await db.query('SELECT * FROM users WHERE id = $1', [userId]);
        user = r.rows[0];
      } else if (email) {
        const r = await db.query('SELECT * FROM users WHERE email = $1', [email]);
        user = r.rows[0];
      }

      if (!user) return res.status(200).send('ok');

      await db.pool.query('BEGIN');
      try {
        await db.query('UPDATE users SET is_active = true WHERE id = $1', [user.id]);
        await db.query(
          'INSERT INTO transactions (user_id, type, amount, status, meta) VALUES ($1,$2,$3,$4,$5)',
          [user.id, 'activation', ACTIVATION_FEE, 'approved', JSON.stringify({ reference })]
        );

        if (user.referred_by) {
          await db.query('UPDATE users SET wallet_balance = wallet_balance + $1 WHERE id = $2', [REFERRAL_BONUS, user.referred_by]);
          await db.query(
            'INSERT INTO transactions (user_id, type, amount, status, meta) VALUES ($1,$2,$3,$4,$5)',
            [user.referred_by, 'referral', REFERRAL_BONUS, 'approved', JSON.stringify({ referred_user: user.id })]
          );
        }

        await db.pool.query('COMMIT');
      } catch (err) {
        console.error('activation tx error', err);
        await db.pool.query('ROLLBACK');
      }
    }
  } catch (err) {
    console.error('webhook handling error', err);
  }

  res.status(200).send('ok');
});

module.exports = router;
