const express = require('express');
const { auth } = require('../middleware/auth');
const db = require('../db');

const router = express.Router();

router.get('/', auth, async (req, res) => {
  const userId = req.user.id;
  const userRes = await db.query('SELECT referral_code, wallet_balance FROM users WHERE id = $1', [userId]);
  if (!userRes.rows.length) return res.status(404).json({ error: 'User not found' });
  const referral_code = userRes.rows[0].referral_code;

  const countRes = await db.query('SELECT COUNT(*) FROM users WHERE referred_by = $1', [userId]);
  const earningsRes = await db.query('SELECT COALESCE(SUM(amount),0) AS total FROM transactions WHERE user_id = $1 AND type = $2 AND status = $3', [userId, 'referral', 'approved']);

  res.json({
    referral_link: `${process.env.FRONTEND_URL || 'http://localhost:3000'}/auth/register?ref=${referral_code}`,
    referral_code,
    referrals_count: Number(countRes.rows[0].count),
    referral_earnings: Number(earningsRes.rows[0].total),
    wallet_balance: Number(userRes.rows[0].wallet_balance)
  });
});

module.exports = router;
