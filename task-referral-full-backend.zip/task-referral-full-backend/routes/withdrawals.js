const express = require('express');
const db = require('../db');
const { auth } = require('../middleware/auth');
const { WITHDRAWAL_FEE, WITHDRAWAL_THRESHOLD } = require('../config');

const router = express.Router();

router.post('/', auth, async (req, res) => {
  const userId = req.user.id;
  const amount = Number(req.body.amount);
  if (!amount || amount <= 0) return res.status(400).json({ error: 'Invalid amount' });

  const r = await db.query('SELECT wallet_balance, name, bank_account_number, bank_name, bank_code FROM users WHERE id = $1', [userId]);
  if (!r.rows.length) return res.status(404).json({ error: 'User not found' });
  const user = r.rows[0];

  if (user.wallet_balance < WITHDRAWAL_THRESHOLD) return res.status(400).json({ error: `Minimum wallet to withdraw is ₦${WITHDRAWAL_THRESHOLD}` });

  const totalDeduct = amount + WITHDRAWAL_FEE;
  if (user.wallet_balance < totalDeduct) return res.status(400).json({ error: 'Insufficient funds to cover amount + fee' });

  if (!user.bank_account_number || !user.bank_name || !user.bank_code) return res.status(400).json({ error: 'Please add bank account number, bank name and bank code in your profile before withdrawing' });

  try {
    await db.pool.query('BEGIN');
    await db.query('UPDATE users SET wallet_balance = wallet_balance - $1 WHERE id = $2', [totalDeduct, userId]);
    const w = await db.query('INSERT INTO withdrawals (user_id, amount, fee, status) VALUES ($1,$2,$3,$4) RETURNING *', [userId, amount, WITHDRAWAL_FEE, 'pending']);
    await db.query('INSERT INTO transactions (user_id, type, amount, status, meta) VALUES ($1,$2,$3,$4,$5)', [userId, 'withdrawal', amount, 'pending', JSON.stringify({ withdrawal_id: w.rows[0].id })]);
    await db.pool.query('COMMIT');
    return res.json({ ok: true, withdrawal: w.rows[0] });
  } catch (err) {
    await db.pool.query('ROLLBACK');
    console.error('withdraw request error', err);
    return res.status(500).json({ error: 'Failed to create withdrawal' });
  }
});

router.get('/', auth, async (req, res) => {
  const r = await db.query('SELECT * FROM withdrawals WHERE user_id = $1 ORDER BY created_at DESC', [req.user.id]);
  res.json(r.rows);
});

module.exports = router;
