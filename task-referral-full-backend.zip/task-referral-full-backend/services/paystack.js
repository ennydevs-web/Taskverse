const fetch = require('node-fetch');
const { PAYSTACK_SECRET } = require('../config');

if (!PAYSTACK_SECRET) console.warn('PAYSTACK_SECRET is not set. Paystack calls will fail.');

const headers = {
  Authorization: `Bearer ${PAYSTACK_SECRET}`,
  'Content-Type': 'application/json'
};

async function initializeTransaction(email, amountKobo, callback_url, metadata = {}) {
  const res = await fetch('https://api.paystack.co/transaction/initialize', {
    method: 'POST',
    headers,
    body: JSON.stringify({ email, amount: amountKobo, callback_url, metadata })
  });
  return res.json();
}

async function verifyTransaction(reference) {
  const res = await fetch(`https://api.paystack.co/transaction/verify/${reference}`, {
    method: 'GET',
    headers
  });
  return res.json();
}

async function resolveBankAccount(account_number, bank_code) {
  const res = await fetch(`https://api.paystack.co/bank/resolve?account_number=${account_number}&bank_code=${bank_code}`, {
    method: 'GET',
    headers
  });
  return res.json();
}

async function createTransferRecipient({ name, account_number, bank_code }) {
  const res = await fetch('https://api.paystack.co/transferrecipient', {
    method: 'POST',
    headers,
    body: JSON.stringify({
      type: 'nuban',
      name,
      account_number,
      bank_code
    })
  });
  return res.json();
}

async function initiateTransfer({ source = 'balance', amountKobo, recipient }) {
  const res = await fetch('https://api.paystack.co/transfer', {
    method: 'POST',
    headers,
    body: JSON.stringify({ source, amount: amountKobo, recipient })
  });
  return res.json();
}

module.exports = {
  initializeTransaction,
  verifyTransaction,
  resolveBankAccount,
  createTransferRecipient,
  initiateTransfer
};
